<?php
session_start();
?>




<fieldset>
    <legend><b>PROFILE</b></legend>
	<form action="#" method="POST">
		<br/>
		<table cellpadding="0" cellspacing="0">
			<tr>
				<td>Name</td>
				<td>:</td>
				<td><?php
				echo $_SESSION['name'];


?>

				</td>
				<td rowspan="7" align="center">
					<img width="128" src="<?php
echo $_SESSION['pic'];
					?>"/>
                    <br/>
                    <a href="picture.php">Change</a>
				</td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Email</td>
				<td>:</td>
				<td><?php
				echo $_SESSION['email'];


?></td>
			</tr>		
			<tr><td colspan="3"><hr/></td></tr>			
			<tr>
				<td>Gender</td>
				<td>:</td>
				<td><?php
				echo $_SESSION['gender'];


?></td>
			</tr>
			<tr><td colspan="3"><hr/></td></tr>
			<tr>
				<td>Date of Birth</td>
				<td>:</td>
				<td><?php
				echo $_SESSION['date'];


?></td>
			</tr>
		</table>	
        <hr/>
        <a href="../write/edit_profile.html">Edit Profile</a>	

        
        <a href="logout.php">logout</a>	
	</form>
</fieldset>