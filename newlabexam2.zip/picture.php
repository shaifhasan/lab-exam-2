<?php

session_start();
$u=$_SESSION['user'];
	error_reporting(0);
	if(isset($_POST['submit'])){
	$filename = $_FILES['myfile']['name'];
	
	$fileUploadPath = "pic/".$filename;
	
	
	
		
	if(move_uploaded_file($_FILES['myfile']['tmp_name'], $fileUploadPath)){
		echo "Upload Success";
	}else{
		echo "Upload error";
	}
	$conn = mysqli_connect("localhost","root", "", "m");
if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	$sql="update users set pic='$fileUploadPath' where user='$u'";
	
	if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
	
$_SESSION['pic']=$fileUploadPath;
	header("Location:loggedin_layout.php");

	}
?>
<fieldset>
    <legend><b>PROFILE PICTURE</b></legend>
    <form action="#" method="post" enctype="multipart/form-data">
        <img width="128" src="../image/user.png" />
        <br />
        <input type="file" name="myfile">
        <hr />
        <input type="submit" name="submit" value="Submit">
    </form>
</fieldset>