<?php
session_start();
session_destroy();
setcookie("re","",time()-1000,"/");
header("location:login.php");
?>