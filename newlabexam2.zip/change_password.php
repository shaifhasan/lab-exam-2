<?php

session_start();

    error_reporting(0);
    if(isset($_POST['submit'])){
    $u=$_SESSION['user'];
$l=$_POST['n'];
    $conn = mysqli_connect("localhost","root", "", "m");
if(!$conn){
        die("Connection Error!".mysqli_connect_error());
    }
    $sql="update users set pass='$l' where user='$u'";
    
    if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
    

    header("Location:profile.php");

    }
?>



<fieldset>
    <legend><b>CHANGE PASSWORD</b></legend>
    <form action="#" method="POST">
        <table>
            <tr>
                <td><font size="3">Current Password</font></td>
				<td>:</td>
                <td><input type="password" name="p" />
<?php   if(isset($_POST['p'])){
        
    if (empty($_POST['p'])) {
    echo "*pass is required";
    }
}
    ?>
                </td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="green">New Password</font></td>
				<td>:</td>
                <td><input type="password" name="n" />
                <?php   if(isset($_POST['n'])){
        
    if (empty($_POST['n'])) {
    echo "*empty";
    }
}
    ?></td>
                <td></td>
            </tr>
            <tr>
                <td><font size="3" color="red">Retype New Password</font></td>
				<td>:</td>
                <td><input type="password" name="o" />
                <?php   if(isset($_POST['o'])){
        
    if (empty($_POST['o'])) {
    echo "*empty";
    }
}
    ?></td>
                <td></td>
            </tr>
        </table>
        <hr />
        <input type="submit" name="submit" value="Submit" />
    </form>
</fieldset>