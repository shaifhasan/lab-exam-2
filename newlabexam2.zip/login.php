<?php
session_start();

if(isset($_COOKIE["re"]))
{
	header("location:loggedin_layout.php");
}
else{
	if(isset($_POST['submit'])){

     	$id=trim($_POST['u']);
	   	$pass=trim($_POST['p']);
		$conn = mysqli_connect("localhost","root", "", "m");
if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	$sql="select user,pass,name,email,gender,date,pic from users where user='$id'";
	
$result = mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
if($row['pass']==$pass)
{
	$_SESSION['user']=$row['user'];
	$_SESSION['pic']=$row['pic'];
	$_SESSION['name']=$row['name'];
	$_SESSION['email']=$row['email'];
	$_SESSION['gender']=$row['gender'];
	$_SESSION['date']=$row['date'];
	$_SESSION['pass']=$row['pass'];
		if(isset($_POST['remember']))
		{
			 setcookie("re","r",time()+(85400*2),"/"); 
		}
	header("location:loggedin_layout.php");


}
else
    echo "login fail";


}
}
	
	

?>

<fieldset>
    <legend><b>LOGIN</b></legend>
    <form action="#" method="POST">
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text" name="u">
			<?php	if(isset($_POST['name'])){
		
	if (empty($_POST['u'])) {
    echo "*user is required";
    }
}
	?></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password" name="p">
				<?php	if(isset($_POST['p'])){
		
	if (empty($_POST['p'])) {
    echo "*pass is required";
    }
}
	?></td>
            </tr>
        </table>
        <hr />
		<input name="remember"  type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" name="submit" value="Submit">        
		<a href="change_password.php">Forgot Password?</a>
    </form>
</fieldset>